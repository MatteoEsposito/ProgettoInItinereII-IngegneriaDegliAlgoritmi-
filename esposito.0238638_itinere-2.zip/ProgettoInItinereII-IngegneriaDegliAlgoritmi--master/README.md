# Progetto In Itinere II - Corso di Ingegneria Degli Algoritmi -

## Informazioni Generali
Questa Repository contiene il codice sorgente, la demo e la relazione per il Secondo Progetto In Itinere del Corso di *Ingegneria degli Algoritmi*.

## Descrizione Repository
> Nella radice della Repository si trova il PDF della Relazione.

> Nella Cartella Python si trova l'intero algoritmo ( conenuto nella cartella lib classe ProjUtilities.py ) e la demo contenuta nel file main.py

> Nella Cartella TeX si trova il sorgente della Relazione con tutta la sua struttura interna nelle varie cartelle

> Nella Cartella Mat si trova l'eps e il file .fig del grafico prodotto da Matlab

> Nella Cartella Dati si trova la spreadsheet di Excel conteneti tutti i dati raccolti nelle 1000 prove effettuate

> Nella Cartella Papers si trovano i PDF dei docuemnti citati all'interno della Relazione
  (il Paper del prof. Brandes )

